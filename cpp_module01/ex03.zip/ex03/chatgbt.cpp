#include <iostream>
#include <string>
using std::cout;
using std::cin;
using std::string;
using std::endl;

class Weapon {
private:
    string type;
public:
    const string& getType() const {
        return type;
    }
    void setType(const string& newType) {
        type = newType;
    }
};

class HumanA {
private:
    Weapon weapon;
    string name;
public:
    HumanA(const string& newName, const Weapon& newWeapon) : name(newName), weapon(newWeapon) {}

    void attack() const {
        cout << name << " attacks with their " << weapon.getType() << endl;
    }
};

class HumanB {
private:
    Weapon* weapon;
    std::string name;
public:
    HumanB(const string& newName) : name(newName), weapon(nullptr) {}

    void setWeapon(Weapon* newWeapon) {
        weapon = newWeapon;
    }

    void attack() const {
        if (weapon != nullptr) {
            cout << name << " attacks with their " << weapon->getType() << endl;
        } else {
            cout << name << " has no weapon to attack with" << endl;
        }
    }
};

int main() {
    Weapon knife;
    knife.setType("knife");
    HumanA john("John", knife);
    john.attack();

    Weapon gun;
    gun.setType("gun");
    HumanB bob("Bob");
    bob.attack();
    bob.setWeapon(&gun);
    bob.attack();

    return 0;
}
/*
Human B sınıfında weapon için pointer kullandık çünkü weapon olmama olasılığına izin verdik. 
(Pointer null değerini gösterebildiği için) eğer referans kullansaydık constructer ile deault
değer vermek zorunda olacaktık ve referans null değer olamaz. 
 
 Human A sınfında class referans ile gösterildiğinden Human A her zaman weapon a sahip olmuş olacak.
*/