#include "HumanA.hpp"
#include "Weapon.hpp"

HumanA::HumanA(const string& newName, Weapon& gun)
{
    name = newName;
    weapon = gun;
}

void	HumanA::attack(void)
{
	cout << name << " attacks with their " << weapon.getType() << endl;
}
